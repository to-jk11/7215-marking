<?php get_header(); ?>  
<?php $shortname = "portfolio theme"; ?>
<!--
<div id="slideshow_cont">
</div> --> <!-- //slideshow_cont -->
    <?php if(get_option($shortname.'_disable_slideshow','') != "Yes") { ?>
    
        <section class="home_slider">
            <ul id="large_slider">
                <?php
                $slider_arr = array();
                $x = 0;
                $args = array(
                     //'category_name' => 'blog',
                     'post_type' => 'post',
                     'meta_key' => 'ex_show_in_slideshow',
                     'meta_value' => 'Yes',
                     'posts_per_page' => 99
                     );
                query_posts($args);
                $i =1;
                while (have_posts()) : the_post(); 
                //$src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full', false, '' );
                ?>     
                    <li><a href="<?php the_permalink(); ?>"><?php echo get_the_post_thumbnail($post->ID,'full',array('alt'=>'<a href="'.get_permalink().'">'.get_the_title().'</a><br/><p>')) ?></a></li>       
                <?php $i++; endwhile; ?>
                
            </ul>
        </section> 
         <?php wp_reset_query(); ?>     
    <?php }  ?> 
    <div class="home_posts">
        <div class="container">
            <?php
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => 4,
                'meta_key' => 'ex_show_in_homepage',
            );
            query_posts($args);
            while (have_posts()) : the_post();
                $url = '';
                $url = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
            ?>
                <div class="home_post">
                <a href="<?php the_permalink(); ?>">
                    <div class="home_post_bg" style="background-image: url('<?php echo $url; ?>');"></div>
                </a>
                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                 <p><?php echo ds_get_excerpt(90); ?></p>
                </div>
            <?php endwhile; ?>
            <?php wp_reset_query(); ?>
            <div class="clear"></div>
        </div>
    </div>
    <div class="home_featured_text">
        <div class="container">
            <?php echo stripslashes(stripslashes(get_option($shortname.'_featured_text',''))); ?>
        </div>
    </div>
    
                <<div class="container pt-5 pb-5">
    <h1><?php the_title(); ?></h1>

    <?php if(have_posts()) : while(have_posts()) : the_post(); ?>

    <?php the_content(); ?>

    <?php endwhile; endif; ?>  
            
<?php get_footer(); ?>  