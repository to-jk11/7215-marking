$(document).ready(function() {

  		$('.t_menu').sidr({

  			 side: 'right'

  		});



  		$('.close_menu').click(function(){

  			jQuery.sidr('toggle');

  		});
	

    $('.header_menu li').hover(

        function () {

            $('ul:first', this).css('display','block');

        }, 

        function () {

            $('ul:first', this).css('display','none');         

        }

    );  



	$('.header_spacing').css('height', $('#header').outerHeight() + 'px');


	$('.fullplate').css('height', ($(window).height() - $('#header').outerHeight()) + 'px');	


	if($('#header').css('position') == 'absolute') 

		$('#header').css('top', $('.slicknav_menu').outerHeight() + 'px');

	else {

		$('#header').css('top', '0px');                 				

	}



	$('.home_blog_post').hover(

		function() {

			$(this).find('.home_blog_post_hover').css('display','block');

		},

		function() {

			$(this).find('.home_blog_post_hover').css('display','none');

		}

	);



	$('.home_blog_posts_small').hover(

		function() {

			$(this).find('.home_blog_posts_small_hover').css('display','block');

		},

		function() {

			$(this).find('.home_blog_posts_small_hover').css('display','none');

		}

	);

	    

	$(".scroller").on("click",function(){


		$("html, body").animate({ scrollTop: $('.fullplate').outerHeight() }, "slow");


	});	



	$("#large_slider").slippry({
		
	});
	$("#small_slider").bxSlider({
		video: true,
		pager: false
	}); 

	   
});







$(window).load(function() {

	$('#small_slider li iframe').css('height', $('#small_slider li').height() + 'px');

	$('.header_spacing').css('height', $('#header').outerHeight() + 'px');


	$('.fullplate').css('height', ($(window).height() - $('#header').outerHeight()) + 'px');	



	if($('#header').css('position') == 'absolute')

		$('#header').css('top', $('.slicknav_menu').outerHeight() + 'px');

	else {

		$('#header').css('top', '0px');

	}	



});



$(window).scroll(function() {



	$('.header_spacing').css('height', $('#header').outerHeight() + 'px');

	if($('#header').css('position') == 'absolute')

		$('#header').css('top', $('.slicknav_menu').outerHeight() + 'px');

	else {

		$('#header').css('top', '0px');

	}

	

});



$(window).resize(function() {
	$('#small_slider li iframe').css('height', $('#small_slider li').height() + 'px');
	$('.header_spacing').css('height', $('#header').outerHeight() + 'px');

	if($('#header').css('position') == 'absolute')

		$('#header').css('top', $('.slicknav_menu').outerHeight() + 'px');

	else {

		$('#header').css('top', '0px');

	}

});