<?php
/*
	Template Name: Blog
*/
?>
<?php get_header(); ?>	
<div id="content">
	
		<div id="single_cont">
		
			<div id="blog_cont">
		
				<?php
				$category_ID = get_category_id('blog');
				$args = array(
				'category_name' => 'blog',
					 'post_type' => 'post',
					 'posts_per_page' => 4,
					 'cat' => $category_ID,
					 'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1)
					 );
				query_posts($args);
				while (have_posts()) : the_post(); ?>                                            		
					<div class="blog_post">
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<h4><?php the_time('F d, Y');?> </h4>
						<div class="img_cont">
							<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('blog-image'); ?></a>
						</div>
						<p><?php echo ds_get_excerpt('460'); ?></p>
						<a class="read_more" href="<?php the_permalink(); ?>">Read More</a>
					</div>
				<?php endwhile; ?>				
			</div><!--//blog_cont-->
			
			<div class="load_more_cont">
				<div align="center"><div class="load_more_text">
				<?php
				ob_start();
				//next_posts_link('<img src="' . get_bloginfo('stylesheet_directory') . '/images/loading-button.png" />');
				next_posts_link('LOAD MORE');
				$buffer = ob_get_contents();
				ob_end_clean();
				if(!empty($buffer)) echo $buffer;
				?>
				</div></div>
			</div><!--//load_more_cont-->     					
			<?php
			global $wp_query;
			//echo '**' . $wp_query->max_num_pages . '**';	
			$max_pages = $wp_query->max_num_pages;
			?>			
			<div id="max_pages_id" style="display: none;"><?php echo ceil($wp_query->found_posts / 2); //echo $max_pages-1; ?></div>					
			
			<?php wp_reset_query(); ?>                        
		
		</div><!--//single_full_cont-->
		
		<?php //get_sidebar(); ?>
		
		<div class="clear"></div>	
</div><!--//content-->
<script type="text/javascript">
$(document).ready(
function($){
var curPage = 1;
var pagesNum = $("#max_pages_id").html();   // Number of pages	
if(pagesNum == 1)
	$('.load_more_text a').css('display','none');	
  $('#blog_cont').infinitescroll({
 
    navSelector  : "div.load_more_text",            
		   // selector for the paged navigation (it will be hidden)
    nextSelector : "div.load_more_text a:first",    
		   // selector for the NEXT link (to page 2)
    itemSelector : "#blog_cont .blog_post",
		   // selector for all items you'll retrieve
	//behavior: "twitter",
    maxPage: <?php echo $max_pages; ?>
  },function(arrayOfNewElems){
  
  $('#blog_cont').append('<div class="clear"></div>');
  
      //$('.home_post_cont img').hover_caption();
      $('.load_more_text a').css('visibility','visible');
            curPage++;
//            alert(curPage + '**' + pagesNum);
            if(curPage == pagesNum) {
                //$(window).unbind('.infscr');
                $('.load_more_text a').css('display','none');
            } else {}  		      
 
     // optional callback when new content is successfully loaded in.
 
     // keyword `this` will refer to the new DOM content that was just added.
     // as of 1.5, `this` matches the element you called the plugin on (e.g. #content)
     //                   all the new elements that were found are passed in as an array
 
  });  
}  
);
</script>	
<?php get_footer(); ?> 		