<?php
include('settings.php');
if (function_exists('add_theme_support')) {
	add_theme_support('menus');
	register_nav_menu('header-menu','Header Menu');
	register_nav_menu('footer-menu','Footer Menu');
	add_theme_support( 'post-thumbnails' );
    add_image_size('blog-image',800,450,true);
    add_image_size('small-slider-image',1180,490,true);
}
function get_category_id($cat_name){
	$term = get_term_by('name', $cat_name, 'category');
	return $term->term_id;
}
function themename_custom_logo_setup() {
    $defaults = array(
    'height'      => 100,
    'width'       => 400,
    'flex-height' => true,
    'flex-width'  => true,
    'header-text' => array( 'site-title', 'site-description' ),
    );
    add_theme_support( 'custom-logo', $defaults );
   }
   add_action( 'after_setup_theme', 'themename_custom_logo_setup' );
function ds_get_excerpt($num_chars) {
    $temp_str = substr(strip_shortcodes(strip_tags(get_the_content())),0,$num_chars);
    $temp_parts = explode(" ",$temp_str);
    $temp_parts[(count($temp_parts) - 1)] = '';
    
    if(strlen(strip_tags(get_the_content())) > 125)
      return implode(" ",$temp_parts) . '...';
    else
      return implode(" ",$temp_parts);
}
if ( function_exists('register_sidebar') ) {
    
        register_sidebar(array(
                'name'=>'No Sidebar',
		'before_widget' => '<div class="home_widget">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));
         register_sidebar(array(
                'name'=>'No Sidebar',
        'before_widget' => '<div class="home_widget">',
        'after_widget' => '</div>',
        'before_title' => '<h3>',
        'after_title' => '</h3>',
    ));
    
        register_sidebar(array(
                'name'=>'Footer Col 1',
		'before_widget' => '<div class="footer_box">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));	
        register_sidebar(array(
                'name'=>'Footer Col 2',
		'before_widget' => '<div class="footer_box">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));	
        register_sidebar(array(
                'name'=>'Footer Col 3',
		'before_widget' => '<div class="footer_box">',
		'after_widget' => '</div>',
		'before_title' => '<h3>',
		'after_title' => '</h3>',
	));	
        
}
// EX POST CUSTOM FIELD START
add_theme_support('post-thumbnails');

// Add support for different image sizes
add_image_size('smallest', 300, 300, true);
add_image_size('medium', 400, 400, true);
add_image_size('largest', 600, 600, true);

/* Custom fields for PAGES Ends */
// **** PRODUCTION - Template1 Search START ****
class template1_search extends WP_Widget {
	function template1_search() {
		parent::WP_Widget(false, 'Custom Search');
	}
	function widget($args, $instance) {
                $args['search_title'] = $instance['search_title'];
		t1_func_search($args);
	}
	function update($new_instance, $old_instance) {
		return $new_instance;
	}
	function form($instance) {
                $search_title = esc_attr($instance['search_title']);
?>
                <p><label for="<?php echo $this->get_field_id('search_title'); ?>"><?php _e('Title:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('search_title'); ?>" name="<?php echo $this->get_field_name('search_title'); ?>" type="text" value="<?php echo $search_title; ?>" /></label></p>
<?php
	}
 }
function t1_func_search($args = array(), $displayComments = TRUE, $interval = '') {
	global $wpdb;
        echo $args['before_widget']; 
        
        if($args['search_title'] != '')
            echo $args['before_title'] . $args['search_title'] . $args['after_title']; ?>
        <div class="t1_search_cont">
            <form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
            <input type="text" name="s" id="s" />
            <INPUT TYPE="image" SRC="<?php bloginfo('stylesheet_directory'); ?>/images/search-icon.jpg" class="t1_search_icon" BORDER="0" ALT="Submit Form">
	       <!-- <input type="submit" value="SEARCH" /> -->
            </form>
        </div><!--//t1_search_cont-->
        <?php
        echo $args['after_widget'];
        wp_reset_query();
        
}
register_widget('template1_search');  
// **** PRODUCTION - Template1 Search END ****
// **** SOCIAL WIDGETS START ****
class dessign_social extends WP_Widget {
    function dessign_social() {
        parent::WP_Widget(false, 'Dessign Social');
    }
    function widget($args, $instance) {
                $args['social_title'] = $instance['social_title'];
        dessign_social_func($args);
    }
    function update($new_instance, $old_instance) {
        return $new_instance;
    }
    function form($instance) {
                $social_title = esc_attr($instance['social_title']);
?>
                <p><label for="<?php echo $this->get_field_id('social_title'); ?>"><?php _e('Title:'); ?> <input class="widefat" id="<?php echo $this->get_field_id('social_title'); ?>" name="<?php echo $this->get_field_name('social_title'); ?>" type="text" value="<?php echo $social_title; ?>" /></label></p>
<?php
    }
 }
function dessign_social_func($args = array(), $displayComments = TRUE, $interval = '') {
    global $wpdb;
        echo $args['before_widget']; 
        $shortname = "portfolio_theme";
        
        if($args['social_title'] != '')
            echo $args['before_title'] . $args['social_title'] . $args['after_title']; ?>
            <div class="side_social">
                <?php if(get_option($shortname.'_twitter_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_twitter_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/twitter-icon.png" alt="twitter" /></a>
                <?php } ?>
                <?php if(get_option($shortname.'_facebook_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_facebook_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/facebook-icon.png" alt="facebook" /></a>
                <?php } ?>
                <?php if(get_option($shortname.'_google_plus_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_google_plus_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/google-plus-icon.png" alt="google plus" /></a>
                <?php } ?>
                <?php if(get_option($shortname.'_picasa_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_picasa_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/picasa-icon.png" alt="picasa" /></a>
                <?php } ?>
                <?php if(get_option($shortname.'_pinterest_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_pinterest_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/pinterest-icon.png" alt="pinterest" /></a>
                <?php } ?>
                <?php if(get_option($shortname.'_vimeo_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_vimeo_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/vimeo-icon.png" alt="vimeo" /></a>
                <?php } ?>
                <?php if(get_option($shortname.'_vimeo_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_youtube_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/youtube-icon.png" alt="youtube" /></a>
                <?php } ?>
                <?php if(get_option($shortname.'_flickr_link','') != '') { ?>
                    <a href="<?php echo get_option($shortname.'_flickr_link',''); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/flickr-icon.png" alt="youtube" /></a>
                <?php } ?>              
                <div class="clear"></div>
            </div><!--//side_social-->                    
        <?php
        echo $args['after_widget'];
        wp_reset_query();
        
}
register_widget('dessign_social');  
// **** SOCIAL WIDGETS END ****
?>