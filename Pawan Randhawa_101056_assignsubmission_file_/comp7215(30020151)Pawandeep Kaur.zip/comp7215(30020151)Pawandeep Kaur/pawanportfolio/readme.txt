URL:
http://localhost/wordpress/wp-admin/themes.php
User Name: 1322randhawa
Password: 770790