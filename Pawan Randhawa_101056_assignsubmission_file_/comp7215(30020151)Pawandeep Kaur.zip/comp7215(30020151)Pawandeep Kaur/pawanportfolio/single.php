<?php get_header(); ?>	
<div id="content">
		<div id="single_cont">
		<h1><?php the_title(); ?></h1>

    <?php if(has_post_thumbnail()): ?>

        <img src="<?php the_post_thumbnail_url('largest'); ?>" class="img-fluid pb-10">

    <?php endif; ?>
    
    <!-- Display post content below -->
    <?php if(have_posts()) : while(have_posts()) : the_post(); ?>

    <?php the_content(); ?>

    <?php endwhile; endif; ?>   
               																
			
		
		
			
			<div class="clear"></div>
		
		</div><!--//single_left-->
		<?php //get_sidebar(); ?>
		<div class="clear"></div>
</div><!--//content-->
<?php get_footer(); ?> 		